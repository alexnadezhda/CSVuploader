(function($){
    var form = $('#really-simple-csv-importer-form-options');
    if ( form.length ) {
        form.prependTo('#import-upload-form').show();
    }
})(jQuery);